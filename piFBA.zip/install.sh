#/bin/sh

cd /usr/local/bin/indiecity/InstalledApps/pifba/Full
chmod 777 ./fba2x ./fbacapex ./capex.cfg ./fba2x.cfg ./zipname.fba ./rominfo.fba ./FBACache_windows.zip ./fba_029671_clrmame_dat.zip ./roms ./skin ./preview ./preview/*
